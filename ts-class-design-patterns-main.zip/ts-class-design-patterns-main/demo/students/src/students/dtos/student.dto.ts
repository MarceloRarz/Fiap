export class StudentDTO {
  id: number;
  firstName: string;
  lastName: string;
  isActive: boolean;
}
